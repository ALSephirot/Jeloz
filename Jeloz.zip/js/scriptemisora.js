$(document).ready(function(){

	setTimeout(function(){
		$('.kc-wrap').addClass('on')
		$('.kc-wrap').removeClass('off-bottom')
	}, 800);
	
})